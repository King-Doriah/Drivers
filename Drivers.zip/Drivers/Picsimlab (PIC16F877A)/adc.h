void adc_init(void){
    ADCON0bits.ADON = 1;
    ADCON0bits.ADCS0 = 1;
    ADCON1bits.PCFG1 = 1;
}

unsigned int adc_read(void){
	/*Alterar esses bits (CHS2:CHS0)
		para pegar o valor do canal desejado.
	
	CHS2:CHS0: Analog Channel Select bits

	000 = Channel 0 (AN0)
	001 = Channel 1 (AN1)
	010 = Channel 2 (AN2)
	011 = Channel 3 (AN3)
	100 = Channel 4 (AN4)
	101 = Channel 5 (AN5)
	110 = Channel 6 (AN6)
	111 = Channel 7 (AN7)

		*/
    
    ADCON0bits.CHS0 = 0;
    ADCON0bits.CHS1 = 0;
    ADCON0bits.CHS2 = 0;
    
    //////////////////////
    
    ADCON0bits.GO = 1;
    while(ADCON0bits.GO == 1);
    return ((((unsigned int)ADRESH)<<2)|(ADRESL>>6));
}