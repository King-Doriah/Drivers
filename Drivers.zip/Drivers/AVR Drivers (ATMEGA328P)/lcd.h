#define LCD_DDR DDRD
#define LCD_Port    PORTD
#define RS  PD2
#define EN  PD3

void pulse_enable(void){
    _delay_us(1); 
    LCD_Port |= (1<<EN);
    _delay_us(1); 
    LCD_Port &= ~(1<<EN); 
    _delay_us(45);
}

void lcdCmd(unsigned char cmd){
    LCD_Port = (LCD_Port & 0x0F) | (cmd & 0xF0);
    LCD_Port &= ~(1<<RS);
    pulse_enable();
    
    _delay_us(200);
    
    LCD_Port = (LCD_Port & 0x0F) | (cmd<<4);
    pulse_enable();
    _delay_ms(2);
}

void lcdData(unsigned char data){
    LCD_Port = (LCD_Port & 0x0F) | (data & 0xF0);
    LCD_Port |= (1<<RS);
    pulse_enable();
    
    _delay_us(200);
    
    LCD_Port = (LCD_Port & 0x0F) | (data<<4);
    pulse_enable();
    _delay_ms(2);
}

void lcdString(char str[]){
    int i = 0;
    while(str[i] != '\0'){
        lcdData(str[i]);
        i++;
    }
}

void lcdInit(void){
    LCD_DDR = 0xFF;
    _delay_ms(20);
    
    lcdCmd(0x02);	
	lcdCmd(0x28);   
	lcdCmd(0x0c);    
	lcdCmd(0x06); 
	lcdCmd(0x01);  
	_delay_ms(2);
}

void lcdClear(void){
    lcdCmd(0x01);
    lcdCmd(0x80);
}