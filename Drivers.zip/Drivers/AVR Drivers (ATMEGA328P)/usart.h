void initUSART(void){
   UBRR0 = 103; //Baud Rate 9600
   UCSR0B |= (1<<RXEN0)|(1<<TXEN0); //Habilita RX e TX
   UCSR0C |= (1<<UCSZ01)|(1<<UCSZ00); //8 bits de dados
}

char usart_receive(void){
   while(!(UCSR0A & (1<<RXC0)));
   return UDR0;
}

void usart_transmit(char data){
   while(!(UCSR0A & (1<<UDRE0)));
   UDR0 = data;
}

void usart_print(char data[]){
   unsigned int i = 0;
   while(data[i]){
      usart_transmit(data[i]);
      i++;
   }
}

void usart_println(char data[]){
   usart_print(data);
   usart_transmit(0x0A);
   usart_transmit(0x0D);
}

char usart_recv_string(char data[]){
   unsigned int i = 0;
   while(1){
      char ch = usart_receive();
      if(ch == '\n' || ch == '\r' || ch == '\0'){
	 data[i] = '\0';
	 i = 0;
	 break;
      }else{
	 data[i] = ch;
	 i++;
      }
   }
}