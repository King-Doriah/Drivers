int length(char str[]){
	unsigned int len = 0;
	while(str[len] != '\0'){
		len++;
	}
	return i;
}

char get_string(char str[]){
	unsigned int i = 0;
   	while(1){
    	char ch = getch(); //Troca a função caso seja necessário.
      	if(ch == '\n' || ch == '\r' || ch == '\0'){
	 		data[i] = '\0';
	 		i = 0;
	 		break;
      	}else{
	 		data[i] = ch;
	 		i++;
      	}
   	}
}

int cmp(char str[], char str2[]){
   unsigned int i = 0;
   while(str[i] != '\0'){
      if(str[i] != str2[i]){
	 return 1;
      }
      i++;
   }
   return 0;
}
