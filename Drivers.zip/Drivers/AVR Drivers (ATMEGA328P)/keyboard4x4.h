#define Keyboard_DDR	DDRB
#define Keyboard_PORT	PORTB
#define	Keyboard_ST	PINB
#define ROW_A		PB0
#define ROW_B		PB1
#define ROW_C		PB2
#define ROW_D		PB3
#define	COL1		PB4
#define	COL2		PB5
#define	COL3		PB6
#define COL4		PB7


void keyboard4x4Init(void){
   Keyboard_DDR = 0x0F;
}

char keyboard4x4Read(void){
   Keyboard_PORT = 0xFF;
   Keyboard_PORT &= ~(1<<ROW_A);
   if(!(Keyboard_ST & (1<<COL1))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL1))); return '7'; };
   if(!(Keyboard_ST & (1<<COL2))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL2))); return '8'; };
   if(!(Keyboard_ST & (1<<COL3))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL3))); return '9'; };
   if(!(Keyboard_ST & (1<<COL4))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL4))); return '/'; };
   
   
   Keyboard_PORT = 0xFF;
   Keyboard_PORT &= ~(1<<ROW_B);
   if(!(Keyboard_ST & (1<<COL1))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL1))); return '4'; };
   if(!(Keyboard_ST & (1<<COL2))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL2))); return '5'; };
   if(!(Keyboard_ST & (1<<COL3))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL3))); return '6'; };
   if(!(Keyboard_ST & (1<<COL4))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL4))); return 'x'; };
   
   Keyboard_PORT = 0xFF;
   Keyboard_PORT &= ~(1<<ROW_C);
   if(!(Keyboard_ST & (1<<COL1))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL1))); return '1'; };
   if(!(Keyboard_ST & (1<<COL2))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL2))); return '2'; };
   if(!(Keyboard_ST & (1<<COL3))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL3))); return '3'; };
   if(!(Keyboard_ST & (1<<COL4))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL4))); return '-'; };
   
   Keyboard_PORT = 0xFF;
   Keyboard_PORT &= ~(1<<ROW_D);
   if(!(Keyboard_ST & (1<<COL1))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL1))); return 'c'; };
   if(!(Keyboard_ST & (1<<COL2))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL2))); return '0'; };
   if(!(Keyboard_ST & (1<<COL3))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL3))); return '='; };
   if(!(Keyboard_ST & (1<<COL4))){ _delay_ms(20); while(!(Keyboard_ST & (1<<COL4))); return '+'; };
   
   return 'n';
}
