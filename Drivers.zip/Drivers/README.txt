#PT
Este repositório contém drivers que eu escrevi para os Microcontroladores AVR (ATMEGA328P) e (PIC16F877A) para o simulador PICSIMLAB.

#EN
This repository contains drivers I wrote for AVR (ATMEGA328P) and (PIC16F877A) microcontrollers for the PicsimLab simulator.